/* ============================================================
   KRUSE DESIGN — interaction layer
   ============================================================ */
(function () {
  "use strict";

  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const fine = window.matchMedia("(pointer: fine)").matches;
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));

  /* ---------- Loader ---------- */
  const loader = $("#loader");
  const fill = $("#loaderFill");
  const pct = $("#loaderPct");

  function startSite() {
    document.body.classList.add("is-ready");
    // trigger hero reveals already handled by CSS via is-ready + observer
  }

  if (reduce || location.hash.length > 1) {
    if (loader) loader.style.display = "none";
    startSite();
  } else {
    let p = 0;
    const tick = setInterval(() => {
      p += Math.random() * 16 + 6;
      if (p >= 100) { p = 100; clearInterval(tick); finish(); }
      if (fill) fill.style.width = p + "%";
      if (pct) pct.textContent = String(Math.floor(p)).padStart(3, "0");
    }, 130);

    function finish() {
      setTimeout(() => {
        loader.classList.add("is-done");
        startSite();
        setTimeout(() => { loader.style.display = "none"; }, 1100);
      }, 350);
    }
  }

  /* ---------- Scroll progress ---------- */
  const bar = $("#scrollbar");
  function onScrollProgress() {
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + "%";
  }

  /* ---------- Sticky nav ---------- */
  const nav = $("#nav");
  function onNavScroll() {
    nav.classList.toggle("is-stuck", window.scrollY > 40);
  }

  window.addEventListener("scroll", () => {
    onScrollProgress();
    onNavScroll();
  }, { passive: true });
  onScrollProgress(); onNavScroll();

  /* ---------- Reveal on scroll ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("is-in");
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.14, rootMargin: "0px 0px -8% 0px" });

  $$(".reveal").forEach((el, i) => {
    // stagger siblings a touch
    el.style.transitionDelay = (Math.min(i % 6, 5) * 0.06) + "s";
    io.observe(el);
  });

  /* ---------- Count up ---------- */
  const counters = $$(".stat__num");
  const cio = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseInt(el.dataset.count, 10);
      cio.unobserve(el);
      if (reduce) { el.textContent = target; return; }
      const dur = 1400; const t0 = performance.now();
      (function step(now) {
        const k = Math.min(1, (now - t0) / dur);
        const eased = 1 - Math.pow(1 - k, 3);
        el.textContent = Math.round(target * eased);
        if (k < 1) requestAnimationFrame(step);
      })(t0);
    });
  }, { threshold: 0.6 });
  counters.forEach((c) => cio.observe(c));

  /* ---------- Mobile menu ---------- */
  const burger = $("#burger");
  const menu = $("#mobilemenu");
  function toggleMenu(open) {
    const isOpen = open ?? !menu.classList.contains("is-open");
    menu.classList.toggle("is-open", isOpen);
    menu.setAttribute("aria-hidden", String(!isOpen));
    burger.classList.toggle("is-open", isOpen);
    burger.setAttribute("aria-expanded", String(isOpen));
    document.body.style.overflow = isOpen ? "hidden" : "";
  }
  burger.addEventListener("click", () => toggleMenu());
  $$("#mobilemenu a").forEach((a) => a.addEventListener("click", () => toggleMenu(false)));

  /* ---------- Custom cursor ---------- */
  if (fine && !reduce) {
    const ring = $("#cursor");
    const dot = $("#cursorDot");
    let rx = innerWidth / 2, ry = innerHeight / 2, dx = rx, dy = ry;
    window.addEventListener("mousemove", (e) => {
      dx = e.clientX; dy = e.clientY;
      dot.style.transform = `translate(${dx}px, ${dy}px) translate(-50%,-50%)`;
    }, { passive: true });
    (function loop() {
      rx += (dx - rx) * 0.18; ry += (dy - ry) * 0.18;
      ring.style.transform = `translate(${rx}px, ${ry}px) translate(-50%,-50%)`;
      requestAnimationFrame(loop);
    })();
    const hoverables = "a, button, .card, .cap, .client";
    document.addEventListener("mouseover", (e) => {
      if (e.target.closest(hoverables)) ring.classList.add("is-hover");
    });
    document.addEventListener("mouseout", (e) => {
      if (e.target.closest(hoverables)) ring.classList.remove("is-hover");
    });
  }

  /* ---------- Hero parallax (mouse + scroll) ---------- */
  if (!reduce && fine) {
    const silk = $("#heroSilk");
    const content = $("[data-parallax]");
    const hero = $("#hero");
    hero.addEventListener("mousemove", (e) => {
      const r = hero.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      if (silk) silk.style.transform = `translate(${x * -22}px, ${y * -22}px) scale(1.06)`;
      if (content) content.style.transform = `translate(${x * 8}px, ${y * 6}px)`;
    });
    hero.addEventListener("mouseleave", () => {
      if (silk) silk.style.transform = "";
      if (content) content.style.transform = "";
    });
  }

  /* ---------- Card tilt ---------- */
  if (!reduce && fine) {
    $$("[data-tilt]").forEach((card) => {
      const media = $(".card__media", card);
      card.addEventListener("mousemove", (e) => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        media.style.transform = `perspective(900px) rotateY(${x * 7}deg) rotateX(${y * -7}deg) translateY(-6px)`;
      });
      card.addEventListener("mouseleave", () => { media.style.transform = ""; });
    });
  }

  /* ---------- Pause silk SVG animation if reduced motion ---------- */
  if (reduce) {
    $$("svg").forEach((s) => { try { s.pauseAnimations(); } catch (e) {} });
  }

  /* ---------- Smooth anchor offset for fixed nav ---------- */
  $$('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const id = a.getAttribute("href");
      if (id.length < 2) return;
      const el = document.querySelector(id);
      if (!el) return;
      e.preventDefault();
      const y = el.getBoundingClientRect().top + window.scrollY - 70;
      window.scrollTo({ top: y, behavior: reduce ? "auto" : "smooth" });
    });
  });
})();
